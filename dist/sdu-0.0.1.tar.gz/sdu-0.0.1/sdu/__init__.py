"""A set of utilites to make developing scripts simpler and easier

Modules
-------
paths:
    This module contains many useful utilities for dealing with system paths.

terminal:
    A module for helpful utilities with generating CLI's

validation:
    Contains a set of common validation schemes.

"""